# Project report of the Network Design and Implementation for a media company
![alt text](https://github.com/zudeera/Project-report-of-the-Network-design-and-Implementation-for-a-media-company/blob/main/Physical%20Topology.jpg)
![alt text](https://github.com/zudeera/Project-report-of-the-Network-design-and-Implementation-for-a-media-company/blob/main/Logical%20Topology.jpg)
